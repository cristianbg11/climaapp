<?php

namespace frontend\models;

/**
 * This is the ActiveQuery class for [[CultivoFinca]].
 *
 * @see CultivoFinca
 */
class CultivoFincaQuery extends \yii\db\ActiveQuery
{
    /*public function active()
    {
        $this->andWhere('[[status]]=1');
        return $this;
    }*/

    /**
     * @inheritdoc
     * @return CultivoFinca[]|array
     */
    public function all($db = null)
    {
        return parent::all($db);
    }

    /**
     * @inheritdoc
     * @return CultivoFinca|array|null
     */
    public function one($db = null)
    {
        return parent::one($db);
    }
}
